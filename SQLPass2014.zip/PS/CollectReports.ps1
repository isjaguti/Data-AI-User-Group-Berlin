﻿Set-StrictMode -Version Latest
$VerbosePreference = "Continue"
#$VerbosePreference = "SilentlyContinue"

#http://www.powershellmagazine.com/2013/08/19/mastering-everyday-xml-tasks-in-powershell/
#$FolderReport = "/I18N"
#[void][System.Reflection.Assembly]::LoadWithPartialName("System.Xml.XmlDocument");
$FolderReport = "/"
$zipDll = "E:\\DemoPass\\Ionic.Zip.dll"


$Path = "C:\\temp\\IRS-Deployment.xml"  
$PathXML = "C:\\temp\\IRS-Deployment.xml"  
$zipFilePath = "C:\\temp\\IRS-Deployment.zip"

$a = @("/","/Demo","/StaticRep","/StaticRep/Easy","/SmallFleetReports")
$a

# get an XMLTextWriter to create the XML 
$XmlWriter = New-Object System.XMl.XmlTextWriter($Path,$Null)   
# choose a pretty formatting: 
$xmlWriter.Formatting = 'Indented'
$xmlWriter.Indentation = 1 
$XmlWriter.IndentChar = "`t"  
# write the header 
$xmlWriter.WriteStartDocument()   


$XmlWriter.WriteComment('Reports to be deployed') 
$xmlWriter.WriteStartElement('IRS-Deployment') 
$xmlWriter.WriteStartElement('SSRS') 
$XmlWriter.WriteElementString('DeploymentType', 'SSRS') 
#$XmlWriter.WriteAttributeString('manager', 'Tobias') 

$VerbosePreference = "Continue"
$ReportServerUri  = "http://localhost/ReportServer/ReportService2010.asmx"
$proxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential
Write-Verbose "Ich arbeite noch ... "


[System.Reflection.Assembly]::LoadFrom($zipDll) | Out-Null

$proxy.ListChildren($FolderReport, $true) | 
Select TypeName, Path, ID, Name, Description | 
Where-Object  TypeName  -eq "Folder" |
ForEach-Object {
    $item = $_
    [string]$path = $item.Path
 #   [string]$root = $item.Path.Substring(0,$item.Path.Length-$item.Name.Length)
    $item.Path
    
       if(    $a -contains $item.Path)
{
   # $path
   # $pathItems=$path.Split("/") 
    $xmlWriter.WriteStartElement('SSRS-Folder') 
Write-Verbose  "Test Teil 1"

$XmlWriter.WriteAttributeString('Path', $item.Path) 
$XmlWriter.WriteAttributeString('Name', $item.Name) 

$XmlWriter.WriteAttributeString('Parent',(split-path $item.Path))
$XmlWriter.WriteAttributeString('Description', $item.Description) 
    $xmlWriter.WriteEndElement()   
    }


}

Write-Verbose  "Nach Folder" 

 
$type = $Proxy.GetType().Namespace
$datatype = ($type + '.Property')



        $property = New-Object ($datatype)
        $property.Name = "RDCE"
        #$property.Value = ""
        

        #Report SSRS Properties
        #http://msdn.microsoft.com/en-us/library/ms152826.aspx
        $numProperties = 1
        $properties = New-Object ($datatype + '[]')$numProperties
        $properties[0] = $property


$zipfile = new-object Ionic.Zip.ZipFile

$proxy.ListChildren("/", $true) | 
Select TypeName, Path, ID, Name, Description | 
Where-Object  TypeName  -eq "Report" |
ForEach-Object {
#Write-Verbose  "Im Loop"
    $item = $_
    [string]$path = $item.Path
    [string]$root = $item.Path.Substring(0,$item.Path.Length-$item.Name.Length)

      if($root.Length -gt 1 -and $root.EndsWith("/"))
      {
         $root = $root.Substring(0,$root.Length-1)
      }

    Write-Verbose  "root in Loop $root"
       if(    $a -contains $root)
    {

    #$path
    $pathItems=$path.Split("/") 
    $xmlWriter.WriteStartElement('SSRS-Report') 
Write-Verbose  "Test Teil 2"

$XmlWriter.WriteAttributeString('Path', $item.Path) 
$XmlWriter.WriteAttributeString('Name', $item.Name) 

$XmlWriter.WriteAttributeString('Parent', (split-path $item.Path))
$XmlWriter.WriteAttributeString('Description', $item.Description) 



$current_props=  $proxy.GetProperties($item.Path,$properties )


if( $current_props.Count -gt 0)
{
$XmlWriter.WriteElementString($current_props[0].Name, $current_props[0].Value) 
}
    $xmlWriter.WriteEndElement()   


    [byte[]] $reportDefinition = $proxy.GetItemDefinition($item.Path) 
    
    #note here we're forcing the actual definition to be 
    #stored as a byte array
    #if you take out the @() from the 
    #MemoryStream constructor, 
    #you'll get an error
    [System.IO.MemoryStream] $memStream = New-Object System.IO.MemoryStream(@(,$reportDefinition))

       #ZipEntry entry = 
      $e=  $zipfile.AddEntry($item.Path+".rdl", $memStream);
}

}

  $zipfile.Save($zipFilePath)
  $zipfile.Dispose()

# close the "machines" node: 
$xmlWriter.WriteEndElement()  
$xmlWriter.WriteEndElement()   
# finalize the document: 
$xmlWriter.WriteEndDocument() 
$xmlWriter.Flush() 
$xmlWriter.Close() 

##CLS
#$XMLDoc = [xml] (Get-Content $PathXML)
#$XMLDoc."IRS-Deployment".SSRS."SSRS-Report"| Sort-Object Root | Select Root | Group-Object Root |
#
#ForEach-Object {
#    $item = $_
#   # Group-Object liefert Count Name, daher wird auf Name zugegriffen
#   $item.Name
#}

