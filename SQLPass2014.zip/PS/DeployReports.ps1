﻿CLS

#+++++++++++++++++++++++++++++++++++ Funktionen

function MyLog-Write
{
    Param ([string]$LineValue)

    Log-Write -LogPath  $LogFullPath -LineValue "$LineValue"
    Write-Verbose "$LineValue"
}

function Get-ScriptDirectory
{
    $Invocation = (Get-Variable MyInvocation -Scope 1).Value;
    if($Invocation.PSScriptRoot)
    {
        $Invocation.PSScriptRoot;
    }
    Elseif($Invocation.MyCommand.Path)
    {
        Split-Path $Invocation.MyCommand.Path
    }
    else
    {
        $Invocation.InvocationName.Substring(0,$Invocation.InvocationName.LastIndexOf("\"));
    }
}

function SSRS-Stop
{
    MyLog-Write "Stop der Reporting Services"
    Stop-Service "SQL Server Reporting Services (MSSQLSERVER)"
    Start-Sleep -Seconds 15
}

function SSRS-Start
{
    MyLog-Write "Start der Reporting Services"
    Start-Service "SQL Server Reporting Services (MSSQLSERVER)"
    Start-Sleep -Seconds 15
}

function SSRS-CountItem
{
    $b = @()
    $j = 0
    Try {
        $myproxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential
        $myproxy.ListChildren("/", $true) | 
        Select TypeName, Path, Name, Description| 
        ForEach-Object {
            $item = $_
            [string]$path = $item.Path
            $b = $b + $path
            $j++
        } 
    } 
    Catch {
        $j = 0
    }
    $j
}

#+++++++++++++++++++++++++++++++++++ Funktionen



#++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++ Hier geht es los
#++++++++++++++++++++++++++++++++++++++++++++++++++++

#Nur $LogPath editieren: Wichtig: \\ !!!!!!!!
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


$LogPath = "C:\\temp"

. "$LogPath\\Logging_Functions.ps1" 

$LogFile = "IRS-Deployment.log"
$LogFullPath = $LogPath + "\" + $LogFile
Log-Start -LogPath $LogPath -LogName $LogFile -ScriptVersion "1.0"


$zipDll = "$LogPath\\Ionic.Zip.dll"

$Path = "$LogPath\\IRS-Deployment.xml"  
$PathXML = "$LogPath\\IRS-Deployment.xml"  
$zipFilePath = "$LogPath\\IRS-Deployment.zip"

#+++++++++++++++++++++++++++++++++++++Connect SSRS
MyLog-Write "Verbindung zum Reporting_server"
$VerbosePreference = "Continue"
$ReportServerUri  = "http://localhost/ReportServer/ReportService2010.asmx"
$proxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential
MyLog-Write "Verbindung zum Reporting_server erfolgt"
#+++++++++++++++++++++++++++++++++++++Connect SSRS

#+++++++++++++++++++++++++++++++++++++Liste der vorhandenen Verzeichnisse vom SSRS einlesen
MyLog-Write "Liste der vorhandenen Verzeichnisse vom SSRS einlesen"
$a = @()
$a.Clear()
$type = $Proxy.GetType().Namespace

$datatype = ($type + '.Property')

$proxy.ListChildren("/", $true) | 
Select TypeName, Path, Name, Description| 
Where-Object TypeName -eq "Folder" |
ForEach-Object {
    $item = $_
    [string]$path = $item.Path
    $a = $a + $path
} 

$XMLDoc = [xml] (Get-Content $PathXML)
#+++++++++++++++++++++++++++++++++++++Liste der vorhandenen Verzeichnisse vom SSRS einlesen



#++++++++++++++++++++++++++++++++++++++Erstellen der Verzeichnisse
MyLog-Write "Erstellen der Verzeichnisse"
$XMLDoc."IRS-Deployment".SSRS."SSRS-Folder" | Sort-Object Path |
ForEach-Object {
    $item = $_

    [string]$path1 = $item.Path
    [string]$name = $item.Name
    [string]$root = $item.Parent
    [string]$description = $item.Description

    if($a -notcontains $path1)
    {
        MyLog-Write "Create: $path1 $root $description : $name" 

        $property = New-Object ($datatype)
        $property.Name = "Description"
        $property.Value = $description
        $folderName = $name

        $numProperties = 1
        $properties = New-Object ($datatype + '[]')$numProperties
        $properties[0] = $property

       # if($root.Length -gt 1 -and $root.EndsWith("/"))
       # {
       #     $root = $root.Substring(0,$root.Length-1)
       # }

        MyLog-Write "Anlage des Verzeichnisses $folderName"
        Try 
        {
                $result = $proxy.CreateFolder($folderName, $root, $properties)  
        } 
        Catch 
        {
            Log-Error -LogPath  $LogFullPath -ErrorDesc $_.Exception.Message -ExitGracefully $False

            $_.Exception.Message
        }
    }
}

MyLog-Write "Erstellen der Verzeichnisse abgeschlossen"
#++++++++++++++++++++++++++++++++++++++Erstellen der Verzeichnisse


#++++++++++++++++++++++++++++++++++++++Löschen der Berichte
Log-Write -LogPath  $LogFullPath -LineValue "Löschen der Berichte"

$XMLDoc = [xml] (Get-Content $PathXML)
$XMLDoc."IRS-Deployment".SSRS."SSRS-Report"|  Select Name,Parent, Path, Description  |
ForEach-Object {
    $item = $_
    $root = $item.Parent
    $deletePath = $item.Path
    MyLog-Write "Lösche $deletePath"

    Try 
    {
        $proxy.DeleteItem($deletePath)  
    } 
    Catch 
    {
        Log-Error -LogPath  $LogFullPath -ErrorDesc $_.Exception.Message -ExitGracefully $False
        $_.Exception.Message
    }
}
MyLog-Write "Löschen der Berichte Abgeschlossen"
#++++++++++++++++++++++++++++++++++++++Löschen der Berichte


#+++++++++++++++++++++++++++++++++++++++++Restart SSRS

#MyLog-Write "Stoppe Reporting Services"
#SSRS-Stop

#MyLog-Write "Starte Reporting Services"
#SSRS-Start

#$Try = 1
#$max_Try = 5
#$SSRS_Running = 0


#do {
#    MyLog-Write "SSRS Startversuch: $Try"
#    $SSRSItems = 0
#    $SSRSItems = SSRS-CountItem

#    MyLog-Write "SSRS-Items gefunden: $SSRSItems"


#    IF($SSRSItems -eq 0 -or $SSRSItems -eq $null)
#    {
#        MyLog-Write "Keine SSRS-Items gefunden, versuche erneut zu starten."
#        SSRS-Start
#    }
#    else
#    {
#        MyLog-Write "Habe SSRS-Items gefunden, SSRS scheint zu laufen."
#        $SSRS_Running = 1
#    }

#    $Try++
# }
# while ($Try -le $max_Try -xor $SSRS_Running -eq 1) 


#IF($SSRS_Running -eq 0)
#{
#    $ErrorDesc = "
    
#    ReportingServices konnte nicht gestartet werden. Bitte überprüfen.  
    
#    !!! Deployment fehlgeschlagen !!!
    
#    "
#    Log-Error -LogPath  $LogFullPath -ErrorDesc "$ErrorDesc" -ExitGracefully $False
#    Write-Error "$ErrorDesc"
#    exit
#}
#+++++++++++++++++++++++++++++++++++++++++Restart SSRS


#+++++++++++++++++++++++++++++++++++++++++Erstellen der Reports
MyLog-Write "Erstellen der Reports"
$overwrite = $true
$warnings = $null

[System.Reflection.Assembly]::LoadFrom($zipDll) | Out-Null
$zipfile = [Ionic.Zip.ZipFile]::Read($zipFilePath)

$XMLDoc = [xml] (Get-Content $PathXML)
$XMLDoc."IRS-Deployment".SSRS."SSRS-Report"|  Select Name,Parent, Path, Description, RDCE  |
ForEach-Object {
    $item = $_
    $RDCE = $item.RDCE
    $root = $item.Parent

    $zipReportPath = $item.Path + ".rdl"

    MyLog-Write "Erstelle den Report $zipReportPath"

    [Ionic.Zip.ZipEntry] $zent = $zipfile[$zipReportPath] 

    [System.IO.MemoryStream] $memStream = New-Object System.IO.MemoryStream

    $zent.Extract($memStream)

    $byteArray1 = $memStream.ToArray();

    #if($root.Length -gt 1 -and $root.EndsWith("/"))
    #{
    #    $root = $root.Substring(0,$root.Length-1)
    #}

    $reportName = $item.Name
    $parent = $root
    $overwrite = $true
    $warnings = $null

    $description = $item.Description

    $property = New-Object ($datatype)
    $property.Name = "Description"
    $property.Value = $description
    $folderName = $name

    $numProperties = 1 + $RDCE.Count
    $properties = New-Object ($datatype + '[]')$numProperties
    $properties[0] = $property
    if($RDCE.Count -eq 1)
    {
        $propertyRDCE = New-Object ($datatype)
        $propertyRDCE.Name = "RDCE"
        $propertyRDCE.Value = "RDCE"
        $properties[1] = $propertyRDCE
    }
    
    MyLog-Write "root $root"

    Try 
    {
        $report = $proxy.CreateCatalogItem("Report", $reportName, $root, $overwrite, $byteArray1, $properties, [ref]$warnings )
    } 
    Catch 
    {
        Log-Error -LogPath  $LogFullPath -ErrorDesc $_.Exception.Message -ExitGracefully $False
        $_.Exception.Message
    }

}
MyLog-Write "Erstellen der Reports abgeschlossen"
#+++++++++++++++++++++++++++++++++++++++++Erstellen der Reports

$zipfile.Dispose()

MyLog-Write "Fertig!"
Log-Finish -LogPath $LogFullPath