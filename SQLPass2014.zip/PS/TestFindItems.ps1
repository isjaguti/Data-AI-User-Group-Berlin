﻿CLS
$username = "User"
$password = "PWD"
$domain = "Computer1"
$SSRSInstance = "Computer2/ReportServer"

$SSRSUseDefaultCredential = $False

$DomainUser = $domain +"\" +$username
$DomainUse
$ReportServerUri  = "http://$SSRSInstance/ReportService2010.asmx"

#$secpasswd = ConvertTo-SecureString $password -AsPlainText -Force
#$mycreds = New-Object System.Management.Automation.PSCredential -ArgumentList $DomainUser, $secpasswd  


$ReportServerUri  = "http://localhost/ReportServer/ReportService2010.asmx"
$proxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential


$type = $Proxy.GetType().Namespace

#create a DataSourceDefinition
$searchConditionType = ($type + '.SearchCondition')
$searchCondition = New-Object($searchConditionType)

$searchCondition.Condition = 'Equals'

$searchCondition.ConditionSpecified = $False
$searchCondition.Name = "Type"
$searchCondition.Values = "Folder"

$searchCondition1 = New-Object($searchConditionType)

$searchCondition1.Condition = 'Equals'

$searchCondition1.ConditionSpecified = $True
$searchCondition1.Name = "Name"
$searchCondition1.Values = "Demo"

$numProperties = 2
$searchConditions = New-Object ($searchConditionType + '[]')$numProperties
$searchConditions[0] = $searchCondition
$searchConditions[1] = $searchCondition1

$type = $Proxy.GetType().Namespace
$datatype = ($type + '.Property')
$property = New-Object ($datatype)
$property.Name = "Recursive"
$property.Value = "True"
        

$catalogitemsarray = $proxy.FindItems("/", 'AND', $property,$searchConditions)  
$catalogitemsarray
foreach ($catalogitem in $catalogitemsarray)
{
   $catalogitem.Path
   "TypeName: " + $catalogitem.TypeName
   $catalogitem.Name
}


$catalogitemsarray.Count 
$catalogitemsarray.Clear()
