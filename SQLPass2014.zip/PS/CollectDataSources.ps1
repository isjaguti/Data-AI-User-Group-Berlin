﻿CLS
Set-StrictMode -Version Latest

$FolderReport = "/"

$Path = "C:\\temp\\IRS-Deployment-DataSource.xml"  
$PathXML = "C:\\temp\\IRS-Deployment-DataSource.xml"  
# get an XMLTextWriter to create the XML 
$XmlWriter = New-Object System.XMl.XmlTextWriter($Path,$Null)   
# choose a pretty formatting: 
$xmlWriter.Formatting = 'Indented'
$xmlWriter.Indentation = 1 
$XmlWriter.IndentChar = "`t"  
# write the header 
$xmlWriter.WriteStartDocument()   
# set XSL statements 
#$xmlWriter.WriteProcessingInstruction("xml-stylesheet", "type='text/xsl' href='style.xsl'")   
# create root element "machines" and add some attributes to it 
$XmlWriter.WriteComment('Data Sources to be deployed') 
$xmlWriter.WriteStartElement('IRS-Deployment') 
$xmlWriter.WriteStartElement('SSRS') 
$XmlWriter.WriteElementString('DeploymentType', 'SSRS-DataSource') 


$VerbosePreference = "Continue"
$ReportServerUri  = "http://localhost/ReportServer/ReportService2010.asmx"
$proxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential
Write-Verbose "Ich arbeite noch ... "

$a = {}
Write-Verbose  "Nach Folder" 
$proxy.ListChildren("/", $true) | 
Select TypeName, Path, ID, Name, Description | 
Where-Object  TypeName  -eq "DataSource" |
ForEach-Object {
#Write-Verbose  "Im Loop"
    $item = $_
    [string]$path = $item.Path
    [string]$root = $item.Path.Substring(0,$item.Path.Length-$item.Name.Length)

      $xmlWriter.WriteStartElement('SSRS-Data-Source') 
      $XmlWriter.WriteAttributeString('Path', $item.Path) 
      $XmlWriter.WriteAttributeString('Name', $item.Name) 
      $XmlWriter.WriteAttributeString('Root', (split-path $item.Path).Replace("\","/"))
      $XmlWriter.WriteAttributeString('Description', $item.Description)


$proxy.GetDataSourceContents($item.Path) |
ForEach-Object {
$item1 =$_
#$XmlWriter.WriteElementString("Extension", $item1.Extension) 
"In Schleife"

$xmlWriter.WriteElementString("Extension",$item1.Extension)
$xmlWriter.WriteElementString("ConnectString",$item1.ConnectString)
$xmlWriter.WriteElementString("UseOriginalConnectString",$item1.UseOriginalConnectString)
$xmlWriter.WriteElementString("OriginalConnectStringExpressionBased",$item1.OriginalConnectStringExpressionBased)
$xmlWriter.WriteElementString("WindowsCredentials",$item1.WindowsCredentials)
$xmlWriter.WriteElementString("ImpersonateUser",$item1.ImpersonateUser)
$xmlWriter.WriteElementString("ImpersonateUserSpecified",$item1.ImpersonateUserSpecified)
$xmlWriter.WriteElementString("Password",$item1.Password)
$xmlWriter.WriteElementString("UserName",$item1.UserName)
$xmlWriter.WriteElementString("Enabled",$item1.Enabled)
$xmlWriter.WriteElementString("CredentialRetrieval",$item1.CredentialRetrieval)


$xmlWriter.WriteEndElement()   
}

 }

 # close the "machines" node: 
$xmlWriter.WriteEndElement()  
$xmlWriter.WriteEndElement()   
# finalize the document: 
$xmlWriter.WriteEndDocument() 
$xmlWriter.Flush() 
$xmlWriter.Close() 
