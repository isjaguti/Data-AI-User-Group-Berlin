﻿CLS
$PathXML = "c:\temp\\IRS-Deployment-DataSource.xml"  

$XMLDoc = [xml] (Get-Content $PathXML)

$XMLDoc."IRS-Deployment".SSRS."SSRS-Data-Source" |  Select Name,Root, Path, Description `
,Extension `
,ConnectString `
,UseOriginalConnectString `
,OriginalConnectStringExpressionBased `
,WindowsCredentials `
,ImpersonateUser `
,ImpersonateUserSpecified `
,Password `
,UserName `
,Enabled `
,CredentialRetrieval `
,EnabledSpecified |
ForEach-Object {
    $item = $_

    $item.Name
    $item.Path
$item.Root
$item.Description

$item.Extension
$item.ConnectString
$item.UseOriginalConnectString
$item.OriginalConnectStringExpressionBased
$item.WindowsCredentials
$item.ImpersonateUser
$item.ImpersonateUserSpecified
$item.Password
$item.UserName
$item.Enabled
$item.EnabledSpecified
$item.CredentialRetrieval

$ReportServerUri  = "http://localhost/ReportServer/ReportService2010.asmx"
$proxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential


$type = $Proxy.GetType().Namespace

#create a DataSourceDefinition
$dataSourceDefinitionType = ($type + '.DataSourceDefinition')
$dataSourceDefinition = New-Object($dataSourceDefinitionType)


$typeProp = $Proxy.GetType().Namespace

#formulate data type we need
$datatype = ($typeProp + '.Property')
[string] $ConString = $item.ConnectString
$ConString = $ConString -replace "Wien","Pauli"
#$ConString = $ConString.Replace("Wien","Pauli")
#$ConString
$dataSourceDefinition.Extension = $item.Extension
$dataSourceDefinition.ConnectString = $ConString#$item.ConnectString

#$dataSourceDefinition.UseOriginalConnectString = $item.UseOriginalConnectString
$dataSourceDefinition.OriginalConnectStringExpressionBased = $item.OriginalConnectStringExpressionBased
$dataSourceDefinition.WindowsCredentials = if($item.WindowsCredentials.ToUpper().StartsWith("T")){$True}ELSE{$False} #$False#$item.WindowsCredentials
$dataSourceDefinition.ImpersonateUser =  if($item.ImpersonateUser.ToUpper().StartsWith("T")){$True}ELSE{$False}
$dataSourceDefinition.ImpersonateUserSpecified = if($item.ImpersonateUserSpecified.ToUpper().StartsWith("T")){$True}ELSE{$False} 
#$dataSourceDefinition.Password = $item.Password
#$dataSourceDefinition.UserName = $item.UserName
$dataSourceDefinition.Enabled =  if($item.Enabled.ToUpper().StartsWith("T")){$True}ELSE{$False} 
$dataSourceDefinition.EnabledSpecified = $true#$item.EnabledSpecified

$CredentialDataType = ($type + '.CredentialRetrievalEnum')
$Cred = new-object ( $CredentialDataType)
$Cred.value__ = 2
#($CredentialDataType).Integrated
#$dataSourceDefinition.CredentialRetrieval = $item.CredentialRetrieval
$dataSourceDefinition.CredentialRetrieval = $Cred
"TesT2"
$Cred
#parent (data folder) – must already exist
#overwrite
#data source definition
#properties

$dataSource = $item.Name
$parent = $item.Root
$overwrite = $true

        $property = New-Object ($datatype)
        $property.Name = "Description"
        $property.Value = $item.Description
        

        $numProperties = 1
        $properties = New-Object ($datatype + '[]')$numProperties
       $properties[0] = $property


#$newDataSource = $proxy.CreateDataSource($dataSource, $parent, $overwrite,$dataSourceDefinition, $properties)

$newDataSource = $proxy.CreateDataSource($dataSource,  $parent, $overwrite,$dataSourceDefinition, $properties)

}

    
