USE [perfdb]
GO
CREATE TABLE [dbo].[event_log](
	[record_date] [datetime] NULL,
	[server_name] [nvarchar](255) NULL,
	[instance_name] [nchar](128) NULL,
	[Database] [nvarchar](255) NULL,
	[event_number] [int] NULL,
	[event_severity] [int] NULL,
	[event_message] [nvarchar](max) NULL
) ON [PRIMARY]

GO

-- jobstep

declare @timestring varchar(30)
declare @record_date datetime
set @timestring='$(ESCAPE_SQUOTE(TIME))'
set @timestring=SUBSTRING(@timestring,1,2)+':'+
		SUBSTRING(@timestring,3,2)+':'+SUBSTRING(@timestring,5,2)


set @record_date= convert(datetime,'$(ESCAPE_SQUOTE(DATE))' + ' ' +@timestring,112)

INSERT INTO perfdb.dbo.event_log
 (record_date,server_name,instance_name,[database],event_number, event_severity,event_message)
SELECT 
@record_date,
'$(ESCAPE_SQUOTE(A-SVR))', 
'$(ESCAPE_SQUOTE(INST))', 
'$(ESCAPE_SQUOTE(A-DBN))', 
$(ESCAPE_SQUOTE(A-ERR)),
$(ESCAPE_SQUOTE(A-SEV)), 
'$(ESCAPE_SQUOTE(A-MSG))'





TRUNCATE TABLE [dbo].[event_log]

backup database perfdb to disk='c:\perflog.bak' with noinit

select * from [dbo].[event_log]