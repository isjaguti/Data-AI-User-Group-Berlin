/* 
CREATE TABLE [dbo].[performance_log](
	[record_date] [datetime] NOT NULL,
	[server_name] [nvarchar](255) NOT NULL,
	[object_name] [nchar](128) NOT NULL,
	[counter_name] [nchar](128) NOT NULL,
	[instance_name] [nchar](128) NULL,
	[cntr_value] [bigint] NOT NULL,
	[cntr_type] [int] NOT NULL
) ON [PRIMARY]
*/

-- 1.1 MB data per run (without indexes)

-- Job
insert into perfdb.dbo.performance_log
select GETDATE(),
convert(nvarchar(50),SERVERPROPERTY('ServerName'))
, *
FROM sys.dm_os_performance_counters

-- Evaluation
select record_date, cntr_value from performance_log where instance_name ='perfdb'
and counter_name = 'Data File(s) Size (KB)'
order by record_date  
