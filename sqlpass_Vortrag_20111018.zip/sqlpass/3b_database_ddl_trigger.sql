--
--  create logtable

CREATE TABLE [dbo].[Database_DDL_Log](
	[DatabaseLogID] [bigint] IDENTITY(1,1) NOT NULL,
	[PostTime] [datetime] NOT NULL,
	[Database_Name] [sysname],
	[DatabaseUser] [sysname] NOT NULL,
	[Event] [sysname] NOT NULL,
	[Schema] [sysname] NULL,
	[Object] [sysname] NULL,
	[TSQL] [nvarchar](max) NOT NULL,
	[XmlEvent] [xml] NOT NULL,
 CONSTRAINT [PK_DatabaseLog_DatabaseLogID] PRIMARY KEY NONCLUSTERED 
(
	[DatabaseLogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

 -- create ddl trigger on database level
 -- can be executed by db_owner or db_ddladmin member

CREATE TRIGGER [ddlDatabaseTriggerLog] ON DATABASE 
FOR DDL_DATABASE_LEVEL_EVENTS AS 
BEGIN
SET NOCOUNT ON;
DECLARE @data XML;
DECLARE @schema sysname;
DECLARE @object sysname;
DECLARE @eventType sysname;
SET @data = EVENTDATA();
SET @eventType = @data.value('(/EVENT_INSTANCE/EventType)[1]', 'sysname');
SET @schema = @data.value('(/EVENT_INSTANCE/SchemaName)[1]', 'sysname');
SET @object = @data.value('(/EVENT_INSTANCE/ObjectName)[1]', 'sysname') 

INSERT [perfdb].[dbo].[Database_DDL_Log] 
(
[PostTime],
[Database_Name] ,
[DatabaseUser], 
[Event], 
[Schema], 
[Object], 
[TSQL], 
[XmlEvent]
) 
VALUES 
(
GETDATE(), 
CONVERT(sysname,DB_NAME()),
CONVERT(sysname, CURRENT_USER), 
@eventType, 
CONVERT(sysname, @schema), 
CONVERT(sysname, @object), 
@data.value('(/EVENT_INSTANCE/TSQLCommand)[1]', 'nvarchar(max)'), 
@data
);
END;

GO

-- disable / enable the trigger (same rights required)

DISABLE TRIGGER [ddlDatabaseTriggerLog] ON DATABASE
GO

ENABLE TRIGGER [ddlDatabaseTriggerLog] ON DATABASE
GO


truncate TABLE [dbo].[Database_DDL_Log]

create table testtable (testcol int)

select * from [dbo].[Database_DDL_Log] order by PostTime desc

