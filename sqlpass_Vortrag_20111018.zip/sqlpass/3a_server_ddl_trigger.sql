--
--  create logtable

CREATE TABLE [dbo].[Server_DDL_Log](
	[serverLogID] [int] IDENTITY(1,1) NOT NULL,
	[PostTime] [datetime] NOT NULL,
	[Login] [sysname] NOT NULL,
	[Event] [sysname] NOT NULL,
	[Database] [sysname] NULL,
	[Object] [sysname] NULL,
	[TSQL] [nvarchar](max) NOT NULL,
	[XmlEvent] [xml] NOT NULL,
 CONSTRAINT [PK_serverLog_serverLogID] PRIMARY KEY NONCLUSTERED 
(
	[serverLogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

 -- create ddl trigger on server level
 -- can be executed by 

CREATE TRIGGER [ddlserverTriggerLog] ON ALL SERVER 
FOR DDL_SERVER_LEVEL_EVENTS AS 
BEGIN
SET NOCOUNT ON;
DECLARE @data XML;
DECLARE @database sysname;
DECLARE @object sysname;
DECLARE @eventType sysname;
SET @data = EVENTDATA();
SET @eventType = @data.value('(/EVENT_INSTANCE/EventType)[1]', 'sysname');
SET @database = @data.value('(/EVENT_INSTANCE/DatabaseName)[1]', 'sysname');
SET @object = @data.value('(/EVENT_INSTANCE/ObjectName)[1]', 'sysname') 

INSERT [perfdb].[dbo].[server_ddl_Log] 
(
[PostTime], 
[Login], 
[Event], 
[Database], 
[Object], 
[TSQL], 
[XmlEvent]
) 
VALUES 
(
GETDATE(), 
CONVERT(sysname, SUSER_NAME()), 
@eventType, 
CONVERT(sysname, @database), 
CONVERT(sysname, @object), 
@data.value('(/EVENT_INSTANCE/TSQLCommand)[1]', 'nvarchar(max)'), 
@data
);
END;

GO

-- disable / enable the trigger (same rights required)

DISABLE TRIGGER [ddlserverTriggerLog] ON DATABASE
GO

ENABLE TRIGGER [ddlserverTriggerLog] ON ALL SERVER
GO


truncate TABLE [dbo].[Server_DDL_Log]

create login test4 WITH PASSWORD = 'enterStrongPasswordHere';

select * from [dbo].[Server_DDL_Log]



