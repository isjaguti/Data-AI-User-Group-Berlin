CREATE TABLE [dbo].[logon_log](
        [UserName] [varchar](255) NOT NULL,
        [IP] [varchar](15) NOT NULL,
        [logon_time] datetime NULL,
        app_name nvarchar(255)
 ) ON [PRIMARY]



CREATE TRIGGER [LOGON_LOG_TRIGGER]
        ON ALL SERVER FOR LOGON
AS
BEGIN
        DECLARE @host NVARCHAR(255);
        DECLARE @logon_time datetime;
        DECLARE @sessionid smallint;
        DECLARE @app_name nvarchar(255);

        SET @host = EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'nvarchar(max)');
        SET @logon_time = EVENTDATA().value('(/EVENT_INSTANCE/PostTime)[1]', 'datetime');
		SET @sessionid = EVENTDATA().value('(/EVENT_INSTANCE/SPID)[1]', 'smallint');
		set @app_name=(select program_name from sys.dm_exec_sessions where session_id=@sessionid)

        insert into perfdb.dbo.logon_log (UserName,IP, logon_time, app_name) values 
						(SYSTEM_USER, @host,@logon_time, @app_name);
                        
END;

truncate table [LOGON_LOG]

select * from [LOGON_LOG]

