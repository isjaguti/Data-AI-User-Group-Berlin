/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	3 Data type precedence
	  sample from https://www.sqlskills.com/blogs/jonathan/implicit-conversions-that-cause-index-scans/

	03-04 varchar vs nvarchar
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @paraNV NVARCHAR(50) = 'SYSREMOTELOGINS TYPES';
DECLARE @paraV VARCHAR(50) = 'SYSREMOTELOGINS TYPES';

SET STATISTICS IO ON;
SELECT [RowID]
      ,[BigIntCol]
      ,[BitCol]
      ,[CharCol]
      ,[DateCol]
      ,[DateTimeCol]
      ,[DateTime2Col]
      ,[DateTimeOffsetCol]
      ,[DecimalCol]
      ,[FloatCol]
      ,[IntCol]
      ,[MoneyCol]
      ,[NCharCol]
      ,[NumericCol]
      ,[NVarchrCol]
      ,[RealCol]
      ,[SmallDateTimeCol]
      ,[SmallIntCol]
      ,[SmallMoneyCol]
      ,[TimeCol]
      ,[TinyIntCol]
      ,[GUIDCol]
      ,[VarcharCol]
  FROM [TestImplicitConvert_SQLCollation].[dbo].[TestImplicitConverts] 
  
 WHERE VarcharCol = @paraNV;

 SELECT  [RowID]
      ,[BigIntCol]
      ,[BitCol]
      ,[CharCol]
      ,[DateCol]
      ,[DateTimeCol]
      ,[DateTime2Col]
      ,[DateTimeOffsetCol]
      ,[DecimalCol]
      ,[FloatCol]
      ,[IntCol]
      ,[MoneyCol]
      ,[NCharCol]
      ,[NumericCol]
      ,[NVarchrCol]
      ,[RealCol]
      ,[SmallDateTimeCol]
      ,[SmallIntCol]
      ,[SmallMoneyCol]
      ,[TimeCol]
      ,[TinyIntCol]
      ,[GUIDCol]
      ,[VarcharCol]
  FROM [TestImplicitConvert_SQLCollation].[dbo].[TestImplicitConverts] 
  
 WHERE NVarchrCol = @paraV

