SET STATISTICS IO ON
�
� SELECT  number,letter FROM [dbo].[DemoSARG] WHERE ISNULL(letter,'Z') = 'Z'
�
�� SELECT  number,letter FROM [dbo].[DemoSARG] WHERE letter = 'Z' OR letter IS NULL


� SELECT  number,letter FROM [dbo].[DemoSARG] WHERE letter = 'Z' 
UNION ALL
� SELECT number,letter FROM [dbo].[DemoSARG] WHERE  letter IS NULL