/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	1 SARGable
	02-02 function on column
********************************************************************/
USE [KnownT-SQLbut];
GO

SET STATISTICS IO ON;
SELECT  [number]
      ,[datum]
      ,[Text]
  FROM [dbo].[DemoSARG] WHERE Cast(number AS varchar(10)) = Cast(10000 AS varchar(10));

  SELECT  [number]
      ,[datum]
      ,[Text]
  FROM [dbo].[DemoSARG] WHERE number = 10000;
