/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	3 Data type precedence
	03-05 type mismatch in join
********************************************************************/
USE [KnownT-SQLbut];
GO

SET STATISTICS IO ON
;WITH T1
AS
(
SELECT MIN([number]) AS m , [datum], MAX([Text]) AS mText, COUNT(DISTINCT [Letter]) AS dLet
FROM [dbo].[DemoSARG]
GROUP BY datum 
)
,t2 AS
(
SELECT MIN([number]) AS m , [datumText], MAX([Text]) AS mText, COUNT(DISTINCT [Letter]) AS dLet
FROM [dbo].DemoDTypePrc
GROUP BY datumText 
)
SELECT * FROM T1
INNER JOIN t2 ON t1.Datum = t2.datumText

;WITH T1
AS
(
SELECT MIN([number]) AS m , [datum], MAX([Text]) AS mText, COUNT(DISTINCT [Letter]) AS dLet
FROM [dbo].[DemoSARG]
GROUP BY datum 
)
,t2 AS
(
SELECT MIN([number]) AS m , [datum], MAX([Text]) AS mText, COUNT(DISTINCT [Letter]) AS dLet
FROM [dbo].DemoDTypePrc
GROUP BY datum 
)
SELECT * FROM T1
INNER JOIN t2 ON t1.Datum = t2.datum
