/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	5 How to generate a series of numbers
	05-04 generate series of numbers
********************************************************************/
USE [KnownT-SQLbut];
GO
DECLARE @start INT=100000
DECLARE @end INT=105000;

SELECT * FROM dbo.getNums(100000,105000);
