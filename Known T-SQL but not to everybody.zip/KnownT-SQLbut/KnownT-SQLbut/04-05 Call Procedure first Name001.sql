/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	4 Parameter Sniffing
	04-05 Call Procedure first Name001
********************************************************************/
USE [KnownT-SQLbut];
GO

SET STATISTICS IO ON;
EXECUTE [demoParameterSniffing] @LName = 'Name001';
