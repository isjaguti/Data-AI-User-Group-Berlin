 /********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	5 How to generate a series of numbers
	05-06 split strings
********************************************************************/
USE [KnownT-SQLbut];
GO

 DECLARE @Delimiter NCHAR(1) = ',';
 DECLARE @ExcludedColumns Varchar(500) = 'column 1,column 2, column 3'
SELECT 
PARSENAME(RTRIM(LTRIM(SUBSTRING(@ExcludedColumns, [Number], CHARINDEX(@Delimiter, @ExcludedColumns + @Delimiter, [Number]) - [Number]))), 1) AS [Item]
               FROM
               (
                 SELECT * FROM dbo.GetNums(0,10000)
               ) AS [n]([Number])
               WHERE [Number] <= CONVERT(INT, LEN(@ExcludedColumns))
                     AND SUBSTRING(@Delimiter + @ExcludedColumns, [Number], LEN(@Delimiter)) = @Delimiter;

--SQL-Server 2016 (it is not possible to determine the order!)
 SELECT RTRIM(LTRIM(value)) AS value FROM string_split(@ExcludedColumns,@Delimiter);
