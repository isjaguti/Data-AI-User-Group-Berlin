 /********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	7 temporary table access from stored procedure
	07-01 Create procedure
********************************************************************/
USE [KnownT-SQLbut];
GO

CREATE OR ALTER PROC dbo.demoAccessTemporyTable
AS
SELECT * FROM #temp;
Update #temp SET ID = ID * 10;
