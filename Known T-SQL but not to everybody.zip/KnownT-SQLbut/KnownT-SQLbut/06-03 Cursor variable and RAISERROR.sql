 /********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	6 Cursor
	06-03 Cursor variable and RAISERROR
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @SchName NVARCHAR(256);
DECLARE @TABName NVARCHAR(256);
DECLARE @message NVARCHAR(100);
DECLARE @mycur CURSOR;
SET @mycur = CURSOR LOCAL FAST_FORWARD
FOR SELECT 
          [sch].[name] AS [SCHName]
        , [tab].[name] AS [TABName]
    FROM  [sys].[schemas] AS [sch]
          INNER JOIN [sys].[Tables] AS [tab] ON [SCH].schema_id = [tab].schema_id;
OPEN @mycur;
WHILE 1 = 1
BEGIN
    FETCH @mycur INTO @SchName
                   , @TABName;
    IF @@Fetch_Status <> 0
    BEGIN
        BREAK;
    END;
    -- Do stuff 
    SET @message = QUOTENAME(@SchName) + '.' + QUOTENAME(@TABName);
	RAISERROR(@message,0,1) WITH NOWAIT;
END;



