/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	5 How to generate a series of numbers
	05-03 Create function GetNums
********************************************************************/
USE [KnownT-SQLbut];
GO

CREATE OR ALTER   FUNCTION [dbo].[GetNums](@low AS BIGINT, @high AS BIGINT) RETURNS
TABLE
AS
RETURN
WITH
L0 AS (SELECT c FROM (VALUES(1),(1)) AS D(c)),		        -- 2
L1 AS (SELECT 1 AS c FROM L0 AS A CROSS JOIN L0 AS B),		-- 4
L2 AS (SELECT 1 AS c FROM L1 AS A CROSS JOIN L1 AS B),		-- 16
L3 AS (SELECT 1 AS c FROM L2 AS A CROSS JOIN L2 AS B),		-- 256
L4 AS (SELECT 1 AS c FROM L3 AS A CROSS JOIN L3 AS B),		-- 65536
L5 AS (SELECT 1 AS c FROM L4 AS A CROSS JOIN L4 AS B),		-- 4294967296
Nums AS (SELECT ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS rownum
FROM L5)
SELECT @low + rownum - 1 AS n
FROM Nums
ORDER BY rownum
OFFSET 0 ROWS FETCH NEXT @high - @low + 1 ROWS ONLY;
