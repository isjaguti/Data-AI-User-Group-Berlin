/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	4 Parameter Sniffing
	04-01 Create data 
********************************************************************/
USE [KnownT-SQLbut];
GO

DROP TABLE IF EXISTS [dbo].parameterSniffing1;

SELECT  n AS ID ,REPLICATE (CAST( CHECKSUM(NEWID()) AS VARCHAR(20)),50) AS stuff,
       CASE WHEN n % 10  > 0 THEN 'Name' + RIGHT( CAST(n AS VARCHAR(8)), 3) ELSE 'Fluegel' END AS LName
INTO dbo.parameterSniffing1
   FROM dbo.getNums(1000000,5000000);

ALTER TABLE [dbo].parameterSniffing1 ALTER COLUMN ID INTEGER NOT NULL;

ALTER TABLE [dbo].parameterSniffing1 ADD  CONSTRAINT [PK_parameterSniffing1] PRIMARY KEY CLUSTERED  (ID ASC);

CREATE NONCLUSTERED INDEX [NC_LName] ON [dbo].parameterSniffing1 ([LName] ASC);
