 /********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	6 Cursor
	06-02 Cursor 1 fetch
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @SchName NVARCHAR(256);
DECLARE @TABName NVARCHAR(256);
DECLARE mycur CURSOR LOCAL FAST_FORWARD
FOR SELECT 
          [sch].[name] AS [SCHName]
        , [tab].[name] AS [TABName]
    FROM  [sys].[schemas] AS [sch]
          INNER JOIN [sys].[Tables] AS [tab] ON [SCH].schema_id = [tab].schema_id;
OPEN mycur;
WHILE 1 = 1
BEGIN
    FETCH mycur INTO @SchName, @TABName;
    IF @@Fetch_Status <> 0
    BEGIN
        BREAK;
    END;
    -- Do stuff 
    PRINT QUOTENAME(@SchName) + '.' + QUOTENAME(@TABName);
END;
CLOSE myCur;
DEALLOCATE mycur;
