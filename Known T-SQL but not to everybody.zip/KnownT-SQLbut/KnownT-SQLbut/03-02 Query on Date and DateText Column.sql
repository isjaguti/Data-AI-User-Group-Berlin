/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	3 Data type precedence
	03-02 Query on Date and DateText Column
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @Datum DATE= '19000101';
SET STATISTICS IO On
SELECT * FROM [dbo].DemoDTypePrc WHERE Datum = @Datum;

SELECT * FROM [dbo].DemoDTypePrc WHERE DatumText = @Datum;

