/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	1 Logical Query processing
	01-01 Normal Select
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @MyTableVar table(  
    GroupNr VARCHAR(5),  
    itemValue int  
); 

INSERT INTO @MyTableVar (GroupNr,itemValue)
VALUES ('a',7);

SELECT GroupNr,itemValue 
FROM @MyTableVar;


