/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	4 Parameter Sniffing
	04-02 Show histogram
********************************************************************/
USE [KnownT-SQLbut];
GO


DBCC SHOW_STATISTICS ("dbo.parameterSniffing1",NC_LName) WITH HISTOGRAM; 

SELECT Lname, COUNT(*)  AS CountLName 
FROM dbo.ParameterSniffing1
GROUP BY LName 
ORDER BY LName;


