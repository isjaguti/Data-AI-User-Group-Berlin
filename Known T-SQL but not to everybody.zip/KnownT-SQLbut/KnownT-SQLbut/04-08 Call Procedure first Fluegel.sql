/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	4 Parameter Sniffing
	04-08 Call Procedure first Fluegel
********************************************************************/
USE [KnownT-SQLbut];
GO

SET STATISTICS IO ON;
EXECUTE demoParameterSniffing  @LName = 'Fluegel';
