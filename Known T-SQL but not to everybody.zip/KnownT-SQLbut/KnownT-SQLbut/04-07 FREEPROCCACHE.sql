/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	4 Parameter Sniffing
	04-07 FREEPROCCACHE
********************************************************************/
USE [KnownT-SQLbut];
GO

DBCC FREEPROCCACHE;

