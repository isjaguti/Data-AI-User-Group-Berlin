/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	4 Parameter Sniffing
	04-03 Simple Select
********************************************************************/
USE [KnownT-SQLbut];
GO

SET STATISTICS IO ON;
SELECT 
      [ID]
    , [stuff]
    , [LName]
FROM  [dbo].[parameterSniffing1]
WHERE [lname] = 'Name001';

SELECT 
      [ID]
    , [stuff]
    , [LName]
FROM  [dbo].[parameterSniffing1]
WHERE [lname] = 'Fluegel';
