/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	4 Parameter Sniffing
	04-04 Create Procedure
********************************************************************/
USE [KnownT-SQLbut];
GO

CREATE OR ALTER PROC [dbo].[demoParameterSniffing] 
    @LName VARCHAR(7)
AS
BEGIN
    SELECT 
          [ID]
        , [stuff]
        , [LName]
    FROM  [dbo].[parameterSniffing1]
    WHERE [LName] = @LName;
END;
