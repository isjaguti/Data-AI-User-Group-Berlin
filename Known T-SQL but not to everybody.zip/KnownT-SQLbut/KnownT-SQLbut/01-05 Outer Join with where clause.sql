/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	1 Logical Query processing
	01-05 Outer Join with where clause
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @MyTableVar1 table(  
    GroupNr VARCHAR(5),  
    itemValue int  
); 

INSERT INTO @MyTableVar1 (GroupNr,itemValue)
VALUES ('a',7),('a',8),('b',1);

DECLARE @MyTableVar2 table(  
    GroupNr VARCHAR(5),  
    itemValue int  
); 

INSERT INTO @MyTableVar2 (GroupNr,itemValue)
VALUES ('a',7),('a',8),('c',1);

SELECT GroupNr,itemValue 
FROM @MyTableVar1;
SELECT GroupNr,itemValue 
FROM @MyTableVar2;

SELECT * 
from @MyTableVar1 AS a
LEFT OUTER JOIN @MyTableVar2 AS B ON a.GroupNr = b.GroupNr
where a.itemValue = b.itemValue;     -- Filter: Is this what you want?

SELECT * 
from @MyTableVar1 AS a
LEFT OUTER JOIN @MyTableVar2 AS B ON a.GroupNr = b.GroupNr AND a.itemValue = b.itemValue;
