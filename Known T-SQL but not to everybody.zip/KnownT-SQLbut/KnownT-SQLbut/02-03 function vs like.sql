/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	1 SARGable
	02-03 function vs like
********************************************************************/
USE [KnownT-SQLbut];
GO

SET STATISTICS IO ON;
SELECT * FROM dbo.DemoSarg 
WHERE LEFT(Text,6)  = 'acidae';

SELECT * FROM dbo.DemoSarg 
WHERE TEXT  LIKE 'acidae%';
