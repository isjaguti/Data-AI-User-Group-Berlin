/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	1 Logical Query processing
	01-07 Filter and Conversion in Where part2

	Sample from Itzik Ben-Gan
	https://www.itprotoday.com/sql-server/logical-query-processing-part-6-where-clause
********************************************************************/
USE [KnownT-SQLbut];
GO

IF OBJECT_ID(N'dbo.Properties', N'U') IS NOT NULL DROP TABLE dbo.Properties;
GO

CREATE TABLE dbo.Properties
(
  name     VARCHAR(128) NOT NULL
CONSTRAINT PK_Properties PRIMARY KEY,
  datatype VARCHAR(128) NOT NULL,
  val      VARCHAR(500) NOT NULL
);


INSERT INTO dbo.Properties(name, datatype, val) VALUES
  ('property1', 'SMALLINT', '1759'    ),
  ('property2', 'VARCHAR',  'abc'     ),
  ('property3', 'INT',      '43112609'),
  ('property4', 'DATE',     '20110212');
--The table holds various properties, with columns for the property name, datatype name and value, with the last stored as a character string. 
--Suppose that you want to filter only integer properties that are greater than 10. You use the following query attempting to achieve this:

WITH C AS
(
  SELECT name, datatype, val
  FROM dbo.Properties
  WHERE datatype IN ('TINYINT', 'SMALLINT', 'INT', 'BIGINT')
)
SELECT *
FROM C
WHERE CAST(val AS BIGINT) > 10;
