/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	5 How to generate a series of numbers
	05-01 generate series from sys.all_objects
********************************************************************/
USE [KnownT-SQLbut];
GO


DECLARE @start INT=100000;
DECLARE @end   INT=105000;
WITH Nums AS
(
  SELECT n = ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) 
  FROM sys.all_objects a
  CROSS JOIN sys.all_objects b

)
SELECT n FROM Nums 
WHERE n BETWEEN @start AND @end
ORDER BY n;
