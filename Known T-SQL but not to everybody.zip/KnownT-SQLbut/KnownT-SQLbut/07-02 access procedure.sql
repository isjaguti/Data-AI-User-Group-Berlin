 /********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	7 temporary table access from stored procedure
	07-02 access procedure
********************************************************************/
USE [KnownT-SQLbut];
GO

DROP TABLE IF EXISTS #temp;
WITH t AS(
SELECT Cast(1 AS int) as ID, Cast('Test String 1' AS NVARCHAR(20)) AS Description
UNION ALL
SELECT 2, 'Test String 2'
)
SELECT * INTO #temp FROM t;

EXECUTE dbo.demoAccessTemporyTable;

SELECT * FROM #temp;