 /********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	6 Cursor
	06-04 Cursor variable dynamic SQL
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @SchName NVARCHAR(256);
DECLARE @TABName NVARCHAR(256);
DECLARE @SQL  nvarchar(MAX);
DECLARE @message NVARCHAR(100);
DECLARE @mycur CURSOR;

SELECT @sql = 
   'SET @mycur = CURSOR LOCAL FAST_FORWARD FOR
         SELECT [sch].[name] AS [SCHName]
        , [tab].[name] AS [TABName]
    FROM  [sys].[schemas] AS [sch]
          INNER JOIN [sys].[Tables] AS [tab] ON [SCH].schema_id = [tab].schema_id; 
   OPEN  @mycur';
EXEC sp_executesql @sql, N'@mycur CURSOR OUTPUT', @mycur OUTPUT;
WHILE 1 = 1
BEGIN
    FETCH @mycur INTO @SchName
                   , @TABName;
    IF @@Fetch_Status <> 0
    BEGIN
        BREAK;
    END;
    -- Do stuff 
    SET @message = QUOTENAME(@SchName) + '.' + QUOTENAME(@TABName);
	RAISERROR(@message,0,1) WITH NOWAIT;
END;
