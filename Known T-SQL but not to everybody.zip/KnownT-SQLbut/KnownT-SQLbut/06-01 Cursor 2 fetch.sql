 /********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	6 Cursor
	06-01 Cursor 2 fetch
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @SchName NVARCHAR(256);
DECLARE @TABName NVARCHAR(256);
DECLARE mycur CURSOR LOCAL FAST_FORWARD
FOR SELECT 
          [sch].[name] AS [SCHName]
        , [tab].[name] AS [TABName]
    FROM  [sys].[schemas] AS [sch]
          INNER JOIN [sys].[Tables] AS [tab] ON [SCH].schema_id = [tab].schema_id;
OPEN mycur;
FETCH mycur INTO @SchName
               , @TABName;
WHILE @@Fetch_Status = 0
BEGIN 
    -- Do stuff 
    PRINT QUOTENAME(@SchName) + '.' + QUOTENAME(@TABName);
    FETCH mycur INTO @SchName
                   , @TABName;
END;
CLOSE myCur;
DEALLOCATE mycur;