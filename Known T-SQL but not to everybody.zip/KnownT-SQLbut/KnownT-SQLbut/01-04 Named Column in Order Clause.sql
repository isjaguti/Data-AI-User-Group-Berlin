/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	1 Logical Query processing
	01-04 Named Column in Order Clause
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @MyTableVar table(  
    GroupNr VARCHAR(5),  
    itemValue int  
); 

INSERT INTO @MyTableVar (GroupNr,itemValue)
VALUES ('a',7);

--SELECT GroupNr,itemValue 
--FROM @MyTableVar;

SELECT GroupNr AS MyGroup ,SUM(itemValue) AS Number
FROM @MyTableVar
WHERE itemValue > 1  
GROUP BY GroupNr 
ORDER BY MyGroup,Number
