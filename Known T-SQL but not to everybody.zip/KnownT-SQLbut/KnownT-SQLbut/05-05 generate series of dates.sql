/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	5 How to generate a series of numbers
	05-05 generate series of dates
********************************************************************/
USE [KnownT-SQLbut];
GO

DECLARE @start DATE='20200101'
DECLARE @end date='20251231';
SELECT DATEADD(day,n,@Start) AS Date FROM dbo.getNums(0,DATEDIFF(DAY,@start,@end));
--Real Life Sample
DECLARE @MinDateUTC DATETIMEOFFSET(0) ='2019-11-19 23:00:00 +00:00';
DECLARE @MaxDateUTC DATETIMEOFFSET(0) ='2019-12-03 23:00:00 +00:00';

SELECT  DATEADD(MINUTE,n* 15,@MinDateUTC) AS deliverydatetimeutc FROM [dbo].[GetNums](0,DATEDIFF(MINUTE,@MinDateUTC,@MaxDateUTC)/15);
