 /********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	7 temporary table access from stored procedure
	07-05 access temporary table mix static and dynamic
********************************************************************/
USE [KnownT-SQLbut];
GO

DROP TABLE IF EXISTS #temp;

DECLARE @SQL nvarchar(MAX);

CREATE TABLE #temp 
(
  dummy int 
);

SET @SQL = 'ALTER TABLE #temp ADD ID int, Description NVARCHAR(20);'
EXECUTE (@SQL);
SET @SQL = 'ALTER TABLE #temp DROP COLUMN dummy;'
EXECUTE (@SQL);

INSERT INTO #temp (ID,Description)
SELECT Cast(1 AS int) as ID, Cast('Test String 1' AS NVARCHAR(20)) AS Description
UNION ALL
SELECT 2, 'Test String 2'


EXECUTE dbo.demoAccessTemporyTable;

SELECT * FROM #temp;