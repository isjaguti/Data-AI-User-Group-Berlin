/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	3 Data type precedence
	03-01 Create data part 1
********************************************************************/
USE [KnownT-SQLbut];
GO
DROP TABLE IF EXISTS dbo.DemoDTypePrc;

WITH T
AS
(
SELECT n AS number
, CASE WHEN N = 1 THEN CAST ('19000101' AS date) 
WHEN N = 2 THEN NULL ELSE 
CAST(DATEADD(day, (ABS(CHECKSUM(NEWID())) % 1580), 0)AS DATE) END  AS datum -- https://stackoverflow.com/questions/794637/how-to-update-rows-with-a-random-date
 ,CAST(TRANSLATE ( (ABS(CHECKSUM(NEWID())) % 1580) ,  '1234567890','abcdefghij' )AS VARCHAR(10)) AS Text  -- SQL-Server 2017
, CAST (CASE n % 28 WHEN 1 THEN 'A' WHEN 2 THEN 'B' WHEN 3 THEN 'C' 
WHEN 3 THEN 'D' WHEN 4 THEN 'E' WHEN 5 THEN 'F' WHEN 6 THEN 'G' WHEN 7 THEN 'H' WHEN 8 THEN 'I' 
WHEN 9 THEN 'J' WHEN 10 THEN 'K' WHEN 11 THEN 'L' WHEN 12 THEN 'M' WHEN 13 THEN 'O' WHEN 14 THEN 'P' 
WHEN 15 THEN 'Q' WHEN 16 THEN 'R' WHEN 17 THEN 'S' WHEN 18 THEN 'T' WHEN 19 THEN 'U' WHEN 20 THEN 'V' 
WHEN 21 THEN 'W' WHEN 22 THEN 'X' WHEN 23 THEN 'Y' WHEN 24 THEN 'Z'
ELSE NULL END AS CHAR(1)) AS Letter

FROM [dbo].[GetNums](0,60000) AS number 

 )
 SELECT Number, Datum, Text, Letter, Cast (Datum AS Varchar(10)) AS DatumText,Cast (Datum AS nVarchar(10)) AS DatumNText,CAST(Text AS CHAR(4)) AS TEXTChar 
 INTO DemoDTypePrc
 FROM t;
ALTER TABLE [dbo].DemoDTypePrc ALTER COLUMN number INTEGER NOT NULL;

ALTER TABLE [dbo].DemoDTypePrc ADD  CONSTRAINT CI_DemoDTypePrc PRIMARY KEY CLUSTERED  ([number] ASC);

CREATE NONCLUSTERED INDEX [NC_Letter1] ON [dbo].DemoDTypePrc ([Letter] ASC)
CREATE NONCLUSTERED INDEX [NC_Text1] ON [dbo].DemoDTypePrc([Text] ASC)
CREATE NONCLUSTERED INDEX [NC_Datum1] ON [dbo].DemoDTypePrc(datum ASC)
CREATE NONCLUSTERED INDEX [NC_DatumText] ON [dbo].DemoDTypePrc(datumText ASC)
CREATE NONCLUSTERED INDEX [NC_DatumNText] ON [dbo].DemoDTypePrc(datumNText ASC)
CREATE NONCLUSTERED INDEX NC_TEXTChar ON [dbo].DemoDTypePrc(TEXTChar ASC);
