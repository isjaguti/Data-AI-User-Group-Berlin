/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	5 How to generate a series of numbers
	05-02 generate series recursive CTE
********************************************************************/
USE [KnownT-SQLbut];
GO


DECLARE @startnum INT=100000;
DECLARE @endnum INT=105000;
WITH gen AS (
    SELECT @startnum AS num
    UNION ALL
    SELECT num+1 FROM gen WHERE num+1<=@endnum
)
SELECT * FROM gen
option (maxrecursion 20000)

