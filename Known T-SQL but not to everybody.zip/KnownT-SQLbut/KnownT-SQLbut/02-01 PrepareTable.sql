/********************************************************************
	Reinhard Fluegel 20201023
	Known T-SQL but not to everybody  (especially beginner)

	2 SARGable
	02-01 PrepareTable
********************************************************************/ 
USE [KnownT-SQLbut];
GO

DROP TABLE IF EXISTS dbo.DemoSARG;

 SELECT n AS number
, CASE WHEN N = 1 THEN CAST ('19000101' AS date) 
WHEN N = 2 THEN NULL ELSE 
CAST(DATEADD(day, (ABS(CHECKSUM(NEWID())) % 65530), 0)AS DATE) END  AS datum -- https://stackoverflow.com/questions/794637/how-to-update-rows-with-a-random-date
 ,CAST(TRANSLATE ( (ABS(CHECKSUM(NEWID())) % 6553067) ,  '1234567890','abcdefghij' )AS VARCHAR(10)) AS Text  -- SQL-Server 2017
, CAST (CASE n % 28 WHEN 1 THEN 'A' WHEN 2 THEN 'B' WHEN 3 THEN 'C' 
WHEN 3 THEN 'D' WHEN 4 THEN 'E' WHEN 5 THEN 'F' WHEN 6 THEN 'G' WHEN 7 THEN 'H' WHEN 8 THEN 'I' 
WHEN 9 THEN 'J' WHEN 10 THEN 'K' WHEN 11 THEN 'L' WHEN 12 THEN 'M' WHEN 13 THEN 'O' WHEN 14 THEN 'P' 
WHEN 15 THEN 'Q' WHEN 16 THEN 'R' WHEN 17 THEN 'S' WHEN 18 THEN 'T' WHEN 19 THEN 'U' WHEN 20 THEN 'V' 
WHEN 21 THEN 'W' WHEN 22 THEN 'X' WHEN 23 THEN 'Y' WHEN 24 THEN 'Z'
ELSE NULL END AS CHAR(1)) AS Letter
 INTO DemoSARG
FROM [dbo].[GetNums](0,60000) AS number ;
ALTER TABLE [dbo].DemoSARG ALTER COLUMN number INTEGER NOT NULL;
ALTER TABLE [dbo].DemoSARG ADD  CONSTRAINT [PK_DemoSARG] PRIMARY KEY CLUSTERED  ([number] ASC);
CREATE NONCLUSTERED INDEX [NC_Letter] ON [dbo].[DemoSARG] ([Letter] ASC);
CREATE NONCLUSTERED INDEX [NC_Text] ON [dbo].[DemoSARG]([Text] ASC);
CREATE NONCLUSTERED INDEX [NC_datum] ON [dbo].[DemoSARG] ([datum] ASC);
